/****************************************************************
 *
 * Solers, Inc. as the author of Enterprise File Delivery 2.1 (EFD 2.1)
 * source code submitted herewith to the Government under contract
 * retains those intellectual property rights as set forth by the Federal 
 * Acquisition Regulations agreement (FAR). The Government has 
 * unlimited rights to redistribute copies of the EFD 2.1 in 
 * executable or source format to support operational installation 
 * and software maintenance. Additionally, the executable or 
 * source may be used or modified for by third parties as 
 * directed by the government.
 *
 * (c) 2009 Solers, Inc.
 ***********************************************************/
package com.solers.lucene;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author <a href="mailto:kevin.conaway@solers.com">Kevin Conaway</a>
 */
public enum Converter {
    
    STRING,
    LONG,
    DATE;
    
    private final static DateFormat FORMAT = new SimpleDateFormat("yyyyMMddHHmm");
    
    public String convertTo(Object o) {
        if (o == null) {
            return null;
        }
        
        switch(this) {
            case DATE:
                synchronized(FORMAT) {
                    return FORMAT.format((Date)o);
                }
            default:
                return String.valueOf(o);
        }
    }
    
    public Object convertFrom(String value) {
        switch(this) {
            case DATE:
                try {
                    synchronized(FORMAT) {
                        return FORMAT.parse(value);
                    }
                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                }
            case LONG:
                return Long.parseLong(value);
            default:
                return value;
        }
    }
    
}
