/****************************************************************
 *
 * Solers, Inc. as the author of Enterprise File Delivery 2.1 (EFD 2.1)
 * source code submitted herewith to the Government under contract
 * retains those intellectual property rights as set forth by the Federal 
 * Acquisition Regulations agreement (FAR). The Government has 
 * unlimited rights to redistribute copies of the EFD 2.1 in 
 * executable or source format to support operational installation 
 * and software maintenance. Additionally, the executable or 
 * source may be used or modified for by third parties as 
 * directed by the government.
 *
 * (c) 2009 Solers, Inc.
 ***********************************************************/
package com.solers.delivery.transport.http.client.methods;

import static com.solers.delivery.transport.http.HTTPHeaders.GBS_RETRIEVAL;

import java.io.IOException;

import org.apache.commons.httpclient.HttpConnection;
import org.apache.commons.httpclient.HttpState;

import com.solers.delivery.transport.http.client.util.Session;

public class GbsGetMethod extends ContentGetMethod {

    private final String consumerContentSetName;

    public GbsGetMethod(Session session, String consumerContentSetName, String remotePath) {
        super(session, remotePath);
        this.consumerContentSetName = consumerContentSetName;
    }

    @Override
    public int execute(HttpState state, HttpConnection conn) throws IOException {
        addRequestHeader(GBS_RETRIEVAL.headerName(), consumerContentSetName);
        return super.execute(state, conn);
    }
}
